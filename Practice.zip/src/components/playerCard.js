import React, { Component } from 'react';
import { View, Text, TouchableHighlight, StyleSheet } from 'react-native';
import mainStyles from '../styles/mainStyles';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as Actions from '../actions';

class PlayerCard extends Component {

    constructor(props) {
        super(props)
        this.state = {
            player: this.props.player
        };
    }

    editScreen = () => {
        this.props.storePlayer(this.state.player.id);
        const navigator = this.props.navigator;
        navigator.navigate('EditPlayer', { title: this.state.player.name })
    }

    render() {

        const {id} = this.props.player;

        console.log(this.props.players[id - 1]);

        return (
            <View style={mainStyles.mv5}>
                <TouchableHighlight
                    style={styles.tochableHighlight}
                    onPress={this.editScreen}>
                    <View style={[mainStyles.container, mainStyles.flexRow, mainStyles.center]}>
                        <View style={mainStyles.ph10}>
                            <Text style={mainStyles.bigText}>{this.props.players[id - 1].id}. {this.props.players[id - 1].name}</Text>
                            <Text>{this.props.player.country}</Text>
                        </View>
                    </View>
                </TouchableHighlight>
            </View>
        );

    }

}

function mapStateToProps(state, props) {
    // console.log('mstp card');
    // console.log(state);
    return {
        loading: state.dataReducer.loading,
        players: state.dataReducer.players.sort((a,b) => {return a.id - b.id})
    };
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators(Actions, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(PlayerCard);

const styles = StyleSheet.create({
    tochableHighlight: {
        backgroundColor: '#EEE',
        padding: 10,
        marginHorizontal: 10
    },
    thumbnail: {
        width: 75,
        height: 75,
        borderRadius: 100
    }
});