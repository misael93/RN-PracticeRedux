import React, { Component } from 'react';
import EditPlayerForm from './editPlayerForm';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as Actions from '../actions';

class EditPlayer extends Component {

    static navigationOptions = ({ navigation }) => {
        return {
            title: navigation.getParam('title')
        };
    };

    handleSubmit = values => {
        console.log(values);
        this.props.updatePlayer(values);
    }

    render() {
        return (
            <EditPlayerForm onSubmit={this.handleSubmit}/>
        );
    }

}

function mapDispatchToProps(dispatch) {
    return bindActionCreators(Actions, dispatch);
}

export default connect(null, mapDispatchToProps)(EditPlayer);