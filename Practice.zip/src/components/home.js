import React, { Component } from 'react';
import {
    View,
    FlatList,
    ActivityIndicator
} from 'react-native';
import PlayerCard from './playerCard';
import mainStyles from '../styles/mainStyles';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as Actions from '../actions';

class Home extends Component {

    static navigationOptions = {
        title: 'Players',
    };

    constructor() {
        super();
    }

    componentDidMount() {
        this.props.getPlayers();
    }

    render() {

        const navigator = this.props.navigation;

        if (this.props.loading) {
            return (
                <View style={mainStyles.activityIndicatorContainer}>
                    <ActivityIndicator animating={true} />
                </View>
            )
        } else {
            return (
                <View style={mainStyles.background}>
                    <FlatList
                        style={mainStyles.mv5}
                        data={this.props.players}
                        renderItem={({ item }) =>
                            <PlayerCard player={item} navigator={navigator} />}
                    />
                </View>
            );
        }

    }

}

function mapStateToProps(state, props) {
    // console.log('mstp home');
    // console.log(state);
    return {
        loading: state.dataReducer.loading,
        players: state.dataReducer.players.sort((a,b) => {return a.id - b.id})
    };
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators(Actions, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Home);