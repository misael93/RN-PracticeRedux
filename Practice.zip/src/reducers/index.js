import { combineReducers } from 'redux';
import { reducer as formReducer } from 'redux-form';
import { GET_PLAYERS } from '../actions';
import { UPDATE_PLAYER } from '../actions';
import { STORE_PLAYER } from '../actions';

let dataState = { players: [], loading: true };

const dataReducer = (state = dataState, action) => {
    switch (action.type) {
        case 'persist/REHYDRATE':
            return { ...state, ...action.payload.dataReducer };
        case GET_PLAYERS:
            return { ...state, ...{ players: action.players, loading: false } };
        case UPDATE_PLAYER:
            return { ...state, ...{ players: action.players, loading: false }, ...{ x: 'lmao' } };
        case STORE_PLAYER:
            state = { ...state, ...{ player:action.player } };
            return state;
        default:
            return state;
    }
};

const rootReducer = combineReducers({
    dataReducer,
    form: formReducer
});

export default rootReducer;
